#Read files#########################################################
Geno<-read.csv("Snp_Data.csv",header=T,row.names=1)
Pheno<-read.csv("1503_files4.csv",header=T,row.names=1)
identical(rownames(Geno),rownames(Pheno))
TRUE

#Edit genotypes#####################################################
#impute missing with averages
unique(unlist(Geno))
#-9  2  1  0
for(i in 1:ncol(Geno)){
  v<-Geno[,i]
  if(any(v==-9)) v[v==-9]<-mean(v[v!=-9])
  Geno[,i]<-v
}
any(unlist(Geno)==-9)
FALSE

Af<-colSums(Geno)/(2*nrow(Geno))
hist(Af)#2 is major allele
range(Af)
#0.4978094 1.0000000
colnames(Geno)<-1:ncol(Geno)
write.csv(Geno,"Resende2012_Geno.csv")

#ouput phenotypes
write.csv(Pheno,"Resende2012_Pheno.csv")


#Predict#############################################################
X<-apply(Geno[,Af<1],2,scale,scale=F)
Y<-Pheno[,1]

X<-X[!is.na(Y),]
Y<-Y[!is.na(Y)]

G<-X%*%t(X)/sum(2*Af[Af<1]*(1-Af[Af<1]))
hist(diag(G))
G.eigen<-eigen(G)
plot(G.eigen$values)

Train<-1:600
Test<-601:861

library(glmnet)
Train.glmnet<-glmnet(x=X[Train,],y=Y[Train],alpha=0,
                     lambda=seq(10,100000,length=100))
Predict.glmnet<-predict(Train.glmnet,newx=X[Test,])
MSE.glmnet<-apply((Predict.glmnet-Y[Test])^2,2,mean)
COR.glmnet<-NULL
for(i in 1:ncol(Predict.glmnet)){
  COR.glmnet<-c(COR.glmnet,cor(Predict.glmnet[,i],Y[Test]))
}
plot(Train.glmnet$lambda,MSE.glmnet)
which.min(MSE.glmnet)
20
Train.glmnet$lambda[20]
80810
MSE.glmnet[20]
587.5615
COR.glmnet[20]
0.1445357

plot(Train.glmnet$lambda,COR.glmnet)
which.max(COR.glmnet)
94
Train.glmnet$lambda[94]
6070
MSE.glmnet[94]
1724.932
COR.glmnet[94]
0.1489744

library(rrBLUP)
A<-A.mat(X,shrink=TRUE)
Z<-cbind(diag(600),matrix(0,600,261))
Train.rrBLUP<-mixed.solve(y=Y[Train],Z=Z,K=A)
Predict.rrBLUP<-as.numeric(Train.rrBLUP$beta)+Train.rrBLUP$u[601:861]
plot(Y[Test],Predict.rrBLUP)
cor(Y[Test],Predict.rrBLUP)
0.4205578
mean((Y[Test]-Predict.rrBLUP)^2)
504.6079

source("RRwithStochasticGradient4.R")
Train.SG<-RRwithSG4(Y[Train], X[Train,],Nm=10,Nepoch=1000,Lambda=0,
                    Every=1)
Predict.SG<-cbind(1,X[Test,])%*%Train.SG$M
MSE.SG<-apply((Predict.SG-Y[Test])^2,2,mean)
COR.SG<-NULL
for(i in 1:ncol(Predict.SG)){
  COR.SG<-c(COR.SG,cor(Predict.SG[,i],Y[Test]))
}
plot(MSE.SG,type="l")
plot(COR.SG,type="l")
MSE.SG[1:10]
COR.SG[1:10]

Train2.SG<-RRwithSG4(Y[Train], X[Train,],Nm=10,Nepoch=1000,Lambda=0,
                    Every=1, PreviousResult = Train.SG)
Predict2.SG<-cbind(1,X[Test,])%*%Train2.SG$M
MSE2.SG<-apply((Predict2.SG-Y[Test])^2,2,mean)
COR2.SG<-NULL
for(i in 1:ncol(Predict2.SG)){
  COR2.SG<-c(COR2.SG,cor(Predict2.SG[,i],Y[Test]))
}
plot(MSE2.SG,type="l")
plot(COR2.SG,type="l")

Train3.SG<-RRwithSG4(Y[Train], X[Train,],Nm=10,Nepoch=1000,Lambda=0,
                     Every=1, PreviousResult = Train2.SG)
Predict3.SG<-cbind(1,X[Test,])%*%Train3.SG$M
MSE3.SG<-apply((Predict3.SG-Y[Test])^2,2,mean)
COR3.SG<-NULL
for(i in 1:ncol(Predict3.SG)){
  COR3.SG<-c(COR3.SG,cor(Predict3.SG[,i],Y[Test]))
}
plot(MSE3.SG,type="l")
plot(COR3.SG,type="l")

Train4.SG<-RRwithSG4(Y[Train], X[Train,],Nm=10,Nepoch=1000,Lambda=0,
                     Every=1, PreviousResult = Train3.SG)
Predict4.SG<-cbind(1,X[Test,])%*%Train4.SG$M
MSE4.SG<-apply((Predict4.SG-Y[Test])^2,2,mean)
COR4.SG<-NULL
for(i in 1:ncol(Predict4.SG)){
  COR4.SG<-c(COR4.SG,cor(Predict4.SG[,i],Y[Test]))
}
plot(MSE4.SG,type="l")
plot(COR4.SG,type="l")

Train5.SG<-RRwithSG4(Y[Train], X[Train,],Nm=10,Nepoch=1000,Lambda=0,
                     Every=1, PreviousResult = Train4.SG)
Predict5.SG<-cbind(1,X[Test,])%*%Train5.SG$M
MSE5.SG<-apply((Predict5.SG-Y[Test])^2,2,mean)
COR5.SG<-NULL
for(i in 1:ncol(Predict5.SG)){
  COR5.SG<-c(COR5.SG,cor(Predict5.SG[,i],Y[Test]))
}
plot(MSE5.SG,type="l")
plot(COR5.SG,type="l")

