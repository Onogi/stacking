#Read files#########################################################
Pheno<-read.csv("pheno_field.csv")
Geno<-read.csv("geno_info.csv",row.names=1,header=F)


#Edit phenotypes####################################################
#Levels of fixed effects
length(unique(Pheno$fixed.eff))
816
sum(is.element(unique(Pheno$fixed.eff),paste("fixeff",1:816,sep="_")))
816
#=>numer of fixeff is 1:816
range(table(Pheno$fixed.eff))
#2 69
hist(table(Pheno$fixed.eff))
#=>model as random effects

#Levels of line effects
length(unique(Pheno$id))
2060
range(table(Pheno$id))
#4 694
hist(table(Pheno$id))
table(Pheno$id)[table(Pheno$id)>10]
#line_2055 line_2056 line_2057 line_2058 line_2060 
#18       160       160       694       422 
hist(table(Pheno$id)[table(Pheno$id)<=10])

#Missing
sum(Pheno$yield==-999)
419
Pheno$yield[Pheno$yield==-999]<-NA
sum(is.na(Pheno$yield))
419
any(Pheno$fixed.eff==-999)
FALSE

#Fit models
Data<-data.frame(y=Pheno$yield,
                 fixed=factor(Pheno$fixed.eff,labels=paste("fixeff",1:816,sep="_")),
                 line=factor(Pheno$id,labels=paste("line",1:2060,sep="_")))
sum(!is.na(Data$y))
18255

library(sommer)
Fit1<-mmer(y~fixed,
           random=~line,
           data=Data)

Fit1$sigma
#$line
#0.1061756
#$units
#0.2024771
dim(Fit1$Vi)
#18525 18525
dim(Fit1$P)
#18525 18525
dim(Fit1$Beta)
#816   3
length(Fit1$U$line$y)
2060

Fit2<-lm(y~fixed+line,data=Data)
plot(c(0,Fit2$coefficients[grep("line",names(Fit2$coefficients))]) + Fit2$coefficients[1],
     Fit1$U$line$y+Fit1$Beta[1,3]);abline(0,1)
#well correlated with some bias

#Use Fit1
#Deregress U
Fit1.R2<-1-diag(Fit1$PevU$line$y)/as.numeric(Fit1$sigma$line)
hist(Fit1.R2)
range(Fit1.R2)
#0.4947867 0.9847829

Fit1.drU<-Fit1$U$line$y/Fit1.R2
plot(Fit1$U$line$y,Fit1.drU);abline(0,1)

names(Fit1.drU)<-rownames(Geno)
write.csv(Fit1.drU, "Raffo2022_Pheno.csv")


#Edit genotypes####################################################
#Impute missing values with means
unique(unlist(Geno))
#1 -1  0 NA
for(i in 1:ncol(Geno)){
  v<-Geno[,i]
  if(any(is.na(v))) v[is.na(v)]<-mean(v[!is.na(v)])
  Geno[,i]<-v
}

Af<-colSums(Geno+1)/(2*nrow(Geno))
hist(Af)
colnames(Geno)<-1:ncol(Geno)

#Code as 0, 1, 2
Geno<-Geno+1
Af<-colSums(Geno)/(2*nrow(Geno))
hist(Af)
write.csv(Geno,"Raffo2022_Geno.csv")

